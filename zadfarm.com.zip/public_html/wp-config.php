<?php
define( 'WP_CACHE', true );


/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u175295951_bMYGI' );

/** Database username */
define( 'DB_USER', 'u175295951_j86tk' );

/** Database password */
define( 'DB_PASSWORD', 'OKiOtlpS90' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'h+i=NwlmsH8m_akY-qOkjrQ2R]},Y %&tJ^jY}]jiOCw~T5%eKhAA)Ph,z-EVL/!' );
define( 'SECURE_AUTH_KEY',   'l*m3/b=`8[JAZPE)XaQa7.JpkO)a]i$ }e)IH?IP[{Y`$XM;.q5=%%A~4H>w|B^S' );
define( 'LOGGED_IN_KEY',     'IJOmS]K<is+=J,Ax_aK|O- i04%H<:$cj?vWhDLnj,8@HL_oMCp(kqrKkEz5UER`' );
define( 'NONCE_KEY',         '<h?dPCKRsqkHT17lengsLzvBVd<@WX` 3d+Z $*pW@(Xk``4!mJ:Vg5;@&@U}<?.' );
define( 'AUTH_SALT',         'oSCxKB4hVE.TegYVpo&d=PQMp:kj9)LMSbV0`_QY&d`.#|^^V#GB(j)zgpE,!_WN' );
define( 'SECURE_AUTH_SALT',  'z#Y ai/lZo`pj.5xB]]kb4m(+]JDNlucV)HdEvZb[W$2K%^v.u:c=!8]j[iE0SD.' );
define( 'LOGGED_IN_SALT',    'e0hiQ,W5=Nf1p,u,_nnoVHvZ8q?Xm}<+kv8Xfib9XQC={[f]U$kIivZas;bL bI#' );
define( 'NONCE_SALT',        'DxWiE-ht4c%0j/YCi$ }sFTWdF.Z}6jphf;Bfo!s=^`tRk[G_q:P:^H&.x[<efrF' );
define( 'WP_CACHE_KEY_SALT', '0ojj:.%eaQ<_)H_JrP0k3X~+bi:;EMy!E?>[J:~lE.bOK35$+X_>&40Ggq  EXx.' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );


/* Add any custom values between this line and the "stop editing" line. */



define( 'FS_METHOD', 'direct' );
define( 'WP_AUTO_UPDATE_CORE', 'minor' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
